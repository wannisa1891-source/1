import { computed } from "vue"

export default function useDayView(selectedDate, shifts){

  const dayShifts = computed(() => {

    if(!selectedDate.value) return []

    return shifts.value.filter(shift => {

      const shiftDate = new Date(shift.date)
      const selected = new Date(selectedDate.value)

      return (
        shiftDate.getFullYear() === selected.getFullYear() &&
        shiftDate.getMonth() === selected.getMonth() &&
        shiftDate.getDate() === selected.getDate()
      )

    })

  })

  return {
    dayShifts
  }

}