<template>
  <div class="day-view-container">
    <div class="day-header" :class="{ 'is-today': isTodayDate(currentDay) }">
      <h2 class="day-title">{{ formatDate }}</h2>
      <button class="add-btn" @click="$emit('openDay', currentDay)">+ เพิ่มเวร</button>
    </div>

    <div class="day-schedules">
      <div v-if="dayShifts.length === 0" class="empty-state">
        <p>ไม่มีเวรในวันนี้</p>
      </div>
      <div
        v-else
        v-for="sch in dayShifts"
        :key="sch.id"
        class="day-shift-card"
        :style="{ borderLeftColor: getShiftColor(sch.shift) }"
        @click="onScheduleClick(sch, $event)"
      >
        <div class="shift-left">
          <span class="shift-dot">{{ getShiftDot(sch.shift) }}</span>
          <div class="shift-details">
            <h4 class="nurse-name">{{ sch.nurseName }}</h4>
            <span class="shift-meta">{{ sch.shift }} — แผนก {{ sch.department }}</span>
          </div>
        </div>
        <div class="shift-right">
          <span class="shift-note" v-if="sch.note">{{ sch.note }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from "vue"
import useDayView from "./DayView"

const props = defineProps({
  currentDate: {
    type: Date,
    required: true
  },
  schedules: {
    type: Array,
    required: true
  },
  getShiftColor: {
    type: Function,
    required: true
  },
  getShiftDot: {
    type: Function,
    required: true
  }
})

const emit = defineEmits(["openDay", "openEditModal"])

// To ensure reactiveness if schedules change externally, 
// we pass a computed that wraps the prop array.
const { currentDay, dayShifts, formatDate } = useDayView(
  computed(() => props.currentDate),
  computed(() => props.schedules)
)

function isTodayDate(date) {
  const today = new Date()
  return (
    date.getFullYear() === today.getFullYear() &&
    date.getMonth() === today.getMonth() &&
    date.getDate() === today.getDate()
  )
}

function onScheduleClick(schedule, event) {
  event.stopPropagation()
  emit("openEditModal", schedule)
}
</script>

<style scoped>
.day-view-container {
  background: var(--card);
  border-radius: 16px;
  overflow: hidden;
}

.day-header {
  padding: 20px 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid var(--bdr);
  background: #f8fafc;
}

.day-header.is-today {
  background: var(--purple-lt);
}

.day-title {
  margin: 0;
  font-size: 20px;
  color: var(--txt);
}

.day-header.is-today .day-title {
  color: var(--purple);
}

.add-btn {
  padding: 8px 16px;
  background: var(--primary);
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 600;
  transition: 0.2s;
}

.add-btn:hover {
  background: var(--primary-dk);
}

.day-schedules {
  padding: 24px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  min-height: 300px;
}

.empty-state {
  text-align: center;
  color: var(--txt2);
  padding: 40px 0;
  font-size: 16px;
}

.day-shift-card {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 20px;
  border-radius: 12px;
  background: var(--bg);
  border: 1px solid var(--bdr);
  border-left-width: 6px;
  border-left-style: solid;
  cursor: pointer;
  transition: 0.25s;
}

.day-shift-card:hover {
  background: #eff6ff;
  border-color: var(--primary);
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(37,99,235,.1);
}

.shift-left {
  display: flex;
  align-items: center;
  gap: 16px;
}

.shift-dot {
  font-size: 20px;
}

.shift-details {
  display: flex;
  flex-direction: column;
}

.nurse-name {
  margin: 0;
  font-size: 16px;
  font-weight: 700;
  color: var(--txt);
}

.shift-meta {
  font-size: 13px;
  color: var(--txt2);
  margin-top: 4px;
}

.shift-note {
  font-size: 13px;
  color: var(--txt2);
  background: var(--amber-lt);
  padding: 4px 12px;
  border-radius: 12px;
}
</style>
